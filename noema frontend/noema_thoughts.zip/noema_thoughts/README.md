# Noema · Thoughts System

Three files + one tiny backend. That's it.

## File structure

```
noema_thoughts/
├── index.html          ← your homepage (with Read Thoughts button added)
├── thoughts.html       ← public archive page
├── admin.html          ← your private studio (password-protected)
├── requirements.txt
└── backend/
    └── main.py         ← FastAPI + SQLite backend
```

---

## 1. Run the backend locally

```bash
pip install -r requirements.txt
uvicorn backend.main:app --reload --port 8001
```

The SQLite database (`thoughts.db`) is created automatically on first run.

---

## 2. Set your admin key

Default key (change before deploying):
```
noema-architect-2024
```

To change it, set the environment variable:
```bash
export NOEMA_ADMIN_KEY="your-secret-key-here"
uvicorn backend.main:app --reload --port 8001
```

Or on Railway/Render: add `NOEMA_ADMIN_KEY` as an environment variable.

---

## 3. Update the API URL in both HTML files

In **thoughts.html** and **admin.html**, find this line near the top of the `<script>`:

```js
const API = 'http://localhost:8001';
```

Change it to your deployed URL, e.g.:
```js
const API = 'https://noema-thoughts.up.railway.app';
```

---

## 4. Access the admin

Open `admin.html` in your browser.
Enter your admin key.
The studio opens — compose thoughts, edit, delete.

---

## 5. Deploy to Railway (optional)

1. Push this folder to a GitHub repo
2. Create a new Railway project → Deploy from GitHub
3. Set environment variable: `NOEMA_ADMIN_KEY=your-secret`
4. Railway auto-detects `requirements.txt` and runs via Procfile

Add a `Procfile` at the root:
```
web: uvicorn backend.main:app --host 0.0.0.0 --port $PORT
```

---

## API summary

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | /thoughts | None | All thoughts (optional ?category=) |
| GET | /thoughts/{id} | None | Single thought |
| GET | /categories | None | All categories in use |
| POST | /admin/thoughts | Admin key | Create thought |
| PUT | /admin/thoughts/{id} | Admin key | Edit thought |
| DELETE | /admin/thoughts/{id} | Admin key | Delete thought |
| GET | /admin/thoughts | Admin key | All thoughts (admin view) |
| GET | /health | None | Health check |
